

#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 10           
// armMotor             motor         8               
// clawMotor            motor         3               
// ---- END VEXCODE CONFIGURED DEVICES ----

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

//one
clawMotor.setStopping(hold);
 clawMotor.setMaxTorque(80, percent);
 clawMotor.setTimeout(2, seconds);

//clawMotor.spinToPosition(-242,degrees);
//clawMotor.spinToPosition(180,degrees);

 clawMotor.spinToPosition(-200, degrees);
 armMotor.spinToPosition(250, degrees);
armMotor.setTimeout(5, seconds);

 
//one delivery

  Drivetrain.driveFor(forward, 500, mm);
  Drivetrain.turnFor(left, 78, degrees, 70, velocityUnits::pct);
  Drivetrain.driveFor(forward, 500, mm);
  
  clawMotor.spinToPosition(180, degrees);

  wait(2,seconds);
  

  //two pickup
  Drivetrain.driveFor(reverse, 500, mm);
  Drivetrain.turnFor(right, 120, degrees, 70, velocityUnits::pct);
  Drivetrain.driveFor(reverse, 500, mm);
  armMotor.spinToPosition(550, degrees);
  wait(1,seconds);
  armMotor.setTimeout(5, seconds);
  clawMotor.spinToPosition(-200, degrees);


  //two delivery
  Drivetrain.driveFor(forward, 500, mm);
  Drivetrain.turnFor(right, 85, degrees, 70, velocityUnits::pct);
  Drivetrain.driveFor(forward, 500, mm);
  clawMotor.spinToPosition(180, degrees);

  wait(2,seconds);

  

  //three pickup
  Drivetrain.driveFor(reverse, 500, mm);
  Drivetrain.turnFor(right, 140, degrees, 70, velocityUnits::pct);
  Drivetrain.driveFor(forward, 500, mm);

  
  wait(1,seconds);
  clawMotor.spinToPosition(-200, degrees);
  armMotor.spinToPosition(250, degrees);
  armMotor.setTimeout(5, seconds);



//three delivery
 Drivetrain.driveFor(forward, 800, mm);
  Drivetrain.turnFor(left, 85, degrees, 70, velocityUnits::pct);
  Drivetrain.driveFor(forward, 500, mm);
  
  clawMotor.spinToPosition(180, degrees);

  wait(2,seconds);
  

  //four pickup
  Drivetrain.driveFor(reverse, 300, mm);
  Drivetrain.turnFor(right, 140, degrees, 70, velocityUnits::pct);
  Drivetrain.driveFor(reverse, 500, mm);
  armMotor.spinToPosition(550, degrees);
  wait(1,seconds);
  armMotor.setTimeout(5, seconds);
  clawMotor.spinToPosition(-200, degrees);


  //four delivery
  Drivetrain.driveFor(forward, 500, mm);
  Drivetrain.turnFor(right, 95, degrees, 70, velocityUnits::pct);
  Drivetrain.driveFor(forward, 460, mm);
  clawMotor.spinToPosition(180, degrees);

  wait(2,seconds);

  // final stop
   Drivetrain.driveFor(reverse, 500, mm);
  Drivetrain.turnFor(left, 140, degrees, 70, velocityUnits::pct);
  Drivetrain.driveFor(reverse, 500, mm);


}
